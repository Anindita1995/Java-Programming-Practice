/**
 *@author Anindita Roy
 *CIS 36B
 **/

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class Translator {
    public static void main(String[] args) throws IOException {
        System.out.println("Welcome to the Spanish Vocabulary Builder!");
        final int SIZE = 1000;

        String[] arrayEnglish = new String[SIZE];
        String[] arraySpanish = new String[SIZE];
        int numElements = 0;

        File engFileData = new File("english.txt");
        Scanner engFile = new Scanner(engFileData);

        File spanishFileData  = new File("spanish.txt");
        Scanner spaFile = new Scanner(spanishFileData);

        while (engFile.hasNextLine() && spaFile.hasNextLine() && numElements < SIZE) {
            arrayEnglish[numElements] = engFile.nextLine();
            arraySpanish[numElements] = spaFile.nextLine();
            numElements++;
        }

        engFile.close();
        spaFile.close();

        Scanner input = new Scanner(System.in);
        boolean running = true;
        final int MENU_ADD = 1;
        final int MENU_REMOVE = 2;
        final int MENU_VIEW = 3;
        final int MENU_QUIT = 4;
        while (running) {
            printArrayConsole(arrayEnglish, numElements);

            System.out.println("Please select a menu option below (1-4):");
            System.out.println("1. Add a new word");
            System.out.println("2. Remove a word");
            System.out.println("3. View a word's translation");
            System.out.println("4. Quit");
            System.out.println("Enter your choice: ");
            System.out.println();

            // Handle non-integer input (like "aba")
            if (!input.hasNextInt()) {
                input.next(); // consume invalid token
                System.out.println("That menu option is invalid. Please try again.");
                continue;
            }

            int choice = input.nextInt();
            input.nextLine(); // consume newline


            if (choice == MENU_ADD) {
                if (numElements >= SIZE) {
                    System.out.println("The dictionary is full.");
                    continue;
                }

                System.out.println("Enter the word to add in English: ");
                String eng = input.nextLine();

                System.out.println("Enter " + eng + "'s Spanish translation: ");
                String spa = input.nextLine();

                System.out.println("Enter the alphabetical position in the list for " + eng +
                        " (0-" + (numElements) + "): ");

                if (!input.hasNextInt()) {
                    input.next();
                    System.out.println("Invalid position! Please enter a location to insert between 0 and " + numElements);
                    continue;
                }

                int pos = input.nextInt();
                input.nextLine();

                boolean okEng = insert(arrayEnglish, numElements, pos, eng);
                boolean okSpa = insert(arraySpanish, numElements, pos, spa);

                if (okEng && okSpa) {
                    numElements++;
                } else {
                    System.out.println("Invalid position! Please enter a location to insert between 0 and " + numElements);
                }

            } else if (choice == MENU_REMOVE) {

                System.out.println("Enter the word to remove: ");
                String wordToRemove = input.nextLine();

                int index = linearSearch(arrayEnglish, wordToRemove, numElements);

                if (index == -1) {
                    System.out.println("Sorry! That word does not exist in this dictionary.");
                } else {
                    boolean removedEng = remove(arrayEnglish, numElements, index);
                    boolean removedSpa = remove(arraySpanish, numElements, index);

                    if (removedEng && removedSpa) {
                        numElements--;
                    }
                }
            } else if (choice == MENU_VIEW) {

                System.out.println("Enter the word in English: ");
                String searchWord = input.nextLine();

                int index = linearSearch(arrayEnglish, searchWord, numElements);

                if (index == -1) {
                    System.out.println("Sorry! That word does not exist in this dictionary.");
                } else {
                    System.out.println(searchWord + " = " + arraySpanish[index]);
                }
            }else if (choice == MENU_QUIT) {

                System.out.print("Enter the name of the output file: ");
                String fileName = input.nextLine();

                printArraysFile(arrayEnglish, arraySpanish, numElements, fileName);
                System.out.println("You may now open " + fileName + " to view the translations.");
                System.out.println("Goodbye!");
                running = false;

            } else {
                System.out.println("That menu option is invalid. Please try again.");
            }
        }

        input.close();



    }

    /**
     * Inserts a new String value into the given array at indexToInsert.
     * Shifts elements to the right to make space.
     *
     * @param array the array of String values
     * @param numElements the current number of elements stored
     * @param indexToInsert the index at which to insert the new value
     * @param newValue the new String value to insert
     * @return true if inserted successfully; false otherwise
     */


    public static boolean insert(String array[], int numElements, int indexToInsert, String newValue) {

        if(numElements >= array.length){
            return false;
        }
        if(indexToInsert < 0 || indexToInsert > numElements){
            return false;
        }
        for(int i = numElements; i > indexToInsert; i--){
            array[i] = array[i - 1];
        }
        array[indexToInsert] = newValue;
        return true; //method stub
    }

    /**
     * Removes the element at indexToRemove from the array.
     * Shifts elements left to fill the gap.
     * Prints an error message if indexToRemove is invalid.
     *
     * @param array the array of String values
     * @param numElements the current number of elements stored
     * @param indexToRemove the index of the element to remove
     * @return true if removed successfully; false otherwise
     */
    public static boolean remove(String array[], int numElements, int indexToRemove) {
        if (indexToRemove < 0 || indexToRemove >= numElements) {
            System.out.println("Invalid position! Please enter a location to remove between 0 and "
                    + (numElements - 1));
            return false;
        }

        for (int i = indexToRemove; i < numElements - 1; i++) {
            array[i] = array[i + 1];
        }
        return true;
    }


    /**
     * Prints the English words array to the console in the format:
     * #. word
     *
     * @param words the list of words in English
     * @param numElements the current number of elements stored
     */
    public static void printArrayConsole(String[] words, int numElements) {
        System.out.println("Below are the words in English:");
        for (int i = 0; i < numElements; i++) {
            System.out.println(i + ". " + words[i]);
        }
    }

    /**
     * Writes the English and Spanish arrays to a file in the format:
     * #. english word: spanish word
     *
     * @param english the list of words in English
     * @param spanish the corresponding list of words in Spanish
     * @param numElements the current number of elements stored
     * @param fileName the output file name
     * @throws IOException if the file cannot be written
     */
    public static void printArraysFile(String[] english, String[] spanish,
                                       int numElements, String fileName) throws IOException {
        PrintWriter out = new PrintWriter(fileName);
        for (int i = 0; i < numElements; i++) {
            out.println(i + ". " + english[i] + ": " + spanish[i]);
        }
        out.close();
    }

    /**
     * Performs a linear search for the given value in the array.
     * Uses String.equals().
     *
     * @param array the list of String values
     * @param value the String to search for
     * @param numElements the number of elements in the list
     * @return the index where value is located, or -1 if not found
     */
    public static int linearSearch(String array[], String value, int numElements) {
        for (int i = 0; i < numElements; i++) {
            if (array[i].equals(value)) {
                return i;
            }
        }
        return -1; //method stub
    }
}
