/**
 *@author Anindita Roy
 *CIS 36B
 *
 */
public class Person {
    //------Information Hiding-------
    private String name;
    private int age;
    private String nationality;

    //--- Accessors------
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    public String getNationality(){
        return nationality;
    }

    //----- Mutators--------

    public void setName(String theName) {
        name = theName;
    }

    public void setAge(int theAge) {
        age = theAge;
    }

    public void setNationality(String theNationality) {
        nationality = theNationality;
    }

    public static void main(String[] arg){


    }
    //without param
    public void greeting(){
        System.out.println("Hi, my name is " + name + "!");
    }
    //with param
    public void greeting(String otherName) {

        System.out.println("Hi, " + otherName + "!");
    }
    public void addYear(){
        age += age;
    }
    public void printPerson() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Nationality: " + nationality);
    }




}
