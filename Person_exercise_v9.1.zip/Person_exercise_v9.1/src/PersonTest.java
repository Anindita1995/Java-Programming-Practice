/**
 * @author Anindita Roy
 * CIS 36B
 */
import java.util.Scanner;
import java.util.ArrayList;

public class PersonTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String name, nationality;
        int age;
        Person person = new Person();

        System.out.println("Welcome!\n\nEnter your name: ");
        name = input.nextLine();
        person.setName(name);
        System.out.println("You entered: " + person.getName() + "\n");

        System.out.print("Enter your age: ");
        age = input.nextInt();
        person.setAge(age);
        System.out.println("You entered: "+ person.getAge() + "\n");
        input.nextLine();

        System.out.print("Enter your nationality: ");
        nationality = input.nextLine();
        person.setNationality(nationality);
        System.out.println("You entered: " + person.getNationality() + "\n");

        System.out.println("Your Summary:\n");
        person.printPerson();

    }
}