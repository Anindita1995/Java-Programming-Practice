/**
*@author Anindita Roy 
*CIS 36B
**/
import java.util.Scanner;

public class Search {
   /**
   *Search the given name one by one
   *@param string array langNameList - a list of Language name
   *@param String langName - user input of Language Name (Name to search)
   *@return location index 
   **/
   
   public static int linearSearch(String[] langNameList, String langName){
            
      for(int i = 0; i < langNameList.length; i++  ){
         if(langName.equals(langNameList[i])){
            return i;
         }
           
      }
      
        return -1;
      }
   public static void main(String[] args) {
      int location;
      String[] mostPopular = { "Java", "Python", "C++", 
         "Javascript", "C#", "SQL", "C", "PHP", "Go",
         "Swift", "Kotlin", "Ruby", "Typescript", "Scala", "R" };

      System.out.print("Welcome!\n\nEnter the name of a programming language: ");
      Scanner input = new Scanner(System.in);
      String name = input.nextLine();
      //call linear search method here
      System.out.print("According to HackerRank ");
      location = linearSearch(mostPopular, name);
      
      if(location == -1) {
         System.out.println(name + " is not one of the top 15 most popular programming languages.");
      } else {
         System.out.println(name + " is language #" + (location + 1) 
            + " in the list of 15 most popular programming languages.");
      }
   }

   /**
   * Searches an array sequentially for a particular value
   * @param array the String array to search
   * @param value the String value to search for
   * @return the index of the item in the array 
   * if it exists in the array or -1 if it doesn't
   */
   //Write linear search method here 
   
}
