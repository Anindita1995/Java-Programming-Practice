/**
 * @author Anindita Roy
 * CIS 36B - Lab 4.2 Prime or Composite
 */
import java.util.Scanner;
import java.io.*;

public class PrimeNums {
   
   /**
    * Performs a binary search using String.equals() and String.compareTo().
    * @param primes - array with list of prime number
    *@param number - a string from user
    @return indext if matches or -1 for not found
    */
   // Binary search using String array
    public static int binarySearch(String[] primes, String number) {
      int low = 0;
      int high = primes.length - 1;
      while (low <= high) {
         int mid = (low + high) / 2;
   
         if (primes[mid].length() > number.length()) {
            high = mid - 1;
         }else if (primes[mid].length() < number.length()) {
            low = mid + 1;
         }else{
            int cmp = primes[mid].compareTo(number);
            if (primes[mid].equals(number)) {
               return mid; 
               }else if (cmp > 0) {
               high = mid - 1;
            }else {
               low = mid + 1;
            }
        }
   }    
      return -1; // not found
   }


   public static void main(String[] args) throws IOException {
      File file = new File("prime_nums.txt");
      Scanner fileScanner = new Scanner(file);
      String line = "";
      while (fileScanner.hasNextLine()) {
         line = line + fileScanner.nextLine() + " ";
      }
      fileScanner.close();

      //clean comma OR space
      String clean = "";
      for (int i = 0; i < line.length(); i++) {
         char ch = line.charAt(i);
         if (ch == ',' || ch == ' ') {
            if (clean.length() > 0 && clean.charAt(clean.length() - 1) != ' ') {
               clean = clean + " ";
            }
         } else {
               clean = clean + ch;
            }
      }

      if (clean.length() > 0 && clean.charAt(clean.length() - 1) == ' ') {
         clean = clean.substring(0, clean.length() - 1);
      }

      int count = 0;
      boolean inNumber = false;

      for (int i = 0; i < clean.length(); i++) {
         if (clean.charAt(i) != ' ') {
            if (!inNumber) {
               count++;
               inNumber = true;
               }
           }else {
            inNumber = false;
           }
      }

   
      String[] primes = new String[count];
      int start = 0;
      int index = 0;
   
      for (int i = 0; i < clean.length(); i++) {
         if (clean.charAt(i) == ' ') {
            primes[index] = clean.substring(start, i);
            index++;
            start = i + 1;
           }
         }
   
      primes[index] = clean.substring(start);
      
      Scanner input = new Scanner(System.in);
      System.out.println("Welcome!");
   
      String userInput = "";

      while (!userInput.equalsIgnoreCase("x")) {
         System.out.print("\nEnter a number from 1 to 10,000 or 'x' to exit:\n");
         userInput = input.next();

         if (!userInput.equalsIgnoreCase("x")) {
            int result = binarySearch(primes, userInput);
            if (result != -1) {
               System.out.println(userInput + " is prime.");
               } else {
                  System.out.println(userInput + " is composite.");
               }
         }
       }

         System.out.println("Goodbye!");
         input.close();
      
      
      
   }//main()

}