
public class ArrayMethod {

	public static void changeValue(int[] value) {
		for(int i = 0; i < value.length; i++) {
			value[i] = i;
		}
	}
	public static int[] grade(int[] marks) {
		for(int i = 0; i < marks.length; i++) {
			marks[i] = i;
		}
		return marks;
	}


	public static void main(String[] args) {
		int[] number = {5, 50, 78, 20};
		//print number befor calling the method to change the number
		for(int i = 0; i < number.length; i++) {
			System.out.print(number[i] + ", ");
		}//output 5, 50, 78, 20

		System.out.println();
		//call the method and pass the array as an argument
		changeValue(number);

		/*
		*method will change the local array value and assign
		new value from the array method
		*/
		for(int i = 0; i < number.length; i++) {
			System.out.print(number[i] + ", ");
		}//output 0, 1, 2, 3

		System.out.println();
		//call method grade();
		number = grade(number);
		for(int i = 0; i < number.length; i++) {
			System.out.print(number[i] + ", ");
		}//output 0, 1, 2, 3

	}
	/*so arrayMethod with RETURN TYPE and without
	return type (void) gives the same output. So
	don't bother to use array with RETURN TYPE.Just
	use VOID
	*/
}
