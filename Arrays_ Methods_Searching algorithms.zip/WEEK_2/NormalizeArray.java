/**
*@author Anindita Roy
*CIS 36B
**/
import java.util.Scanner;

public class NormalizeArray {
   
   // Define your methods and their Javadocs here
   /**
   *Read input values into the array
   *@param double[] arr - list of double digit number
   *@param scnr - Scanner object
   *
   */
   public static void readInput(double[] arr, Scanner scnr){
      for(int i = 0; i < arr.length; i++){
         arr[i] = scnr.nextDouble();
         }
   }
   /**
   *Return the max value of array
   *@param double[] arr - list of double digit number
   *@return max
   */
   public static double getMax(double[] arr){
      double max = arr[0];
      for(int i = 0; i < arr.length; i++){
         if(arr[i] > max){
            max = arr[i];
         }
      }
      return max;
   }
   /**
   *Print normalized values (max - values)
   *@param double[] arr - list of double digit number
   *@param max - variable for maximum value
   *
   */
   
   public static void printNormalizedArray(double[] arr, double max){
      for(int i = 0; i < arr.length; i++){
         System.out.printf("%.1f ", max - arr[i]);
      }
         
   }
   
   public static void main(String[] args) {
      //add your main code here
      Scanner scnr = new Scanner(System.in);
      int size = scnr.nextInt();
      double[] values = new double[size];
      
      readInput(values, scnr);
      double max = getMax(values);
      System.out.printf("Max Value: %.1f\n", max);
      System.out.printf("Normalized Values: ");
      printNormalizedArray(values, max);
      
      
   }
}
