/**
*@author Anindita Roy
*CIS 36B
*
**/
//Add your imports here
import java.util.Scanner;

public class Search {
   //Add your linear search method here with Javadoc from the prior assignment
   /**
   *Search the given name one by one
   *@param string array langNameList - a list of Language name
   *@param String langName - user input of Language Name (Name to search)
   *@return location index 
   **/
   
   public static int linearSearch(String[] mostPopular, String langName){
            
      for(int i = 0; i < mostPopular.length; i++  ){
         if(langName.equals(mostPopular[i])){
            return i;
         }
           
      }      
        return -1;
      }

   //Write your binary search method and its Javadoc here
   /**
   *Search the given name by using Binary Search Algorithm 
   *@param string array langNameList - a list of Language name
   *@param String langName - user input of Language Name (Name to search)
   *@return location index 
   **/
   
   public static int binarySearch(String[] mostInDemand, String demandName ){
         int low = 0;
         int high = mostInDemand.length - 1;
         
         while(low <= high){
            int mid = (low + high) / 2;
            
            int search = demandName.compareTo(mostInDemand[mid]);
            
            if(search == 0){
               return mid;
               }else if(search < 0){ //-1
                  high = mid - 1;                  
               }else {
                  low = mid + 1;
                  }
            
            
         }
         
         return -1;//not found   
   }
   
   public static void main(String[] args) {
      int location;
      String[] mostPopular = { "Java", "Python", "C++", "Javascript", "C#",
         "SQL", "C", "PHP", "Go", "Swift", "Kotlin", "Ruby", "Typescript",
         "Scala", "R" };

      String[] mostInDemand = {"C", "C#", "C++", "Java", "Javascript", "Perl",
         "PHP", "Python", "Ruby", "Visual Basic"};

      System.out.print("Welcome!\n\nEnter the name of a programming language: ");
      Scanner input = new Scanner(System.in);
      String name = input.nextLine();
      //add your call linear search method here from the prior assignment
      
      location = linearSearch(mostPopular, name);
      
      System.out.print("According to HackerRank ");

      if(location == -1) {
         System.out.println(name + " is not one of the top 15 most popular programming languages.");
      } else {
         System.out.println(name + " is language #" + (location + 1)
            + " in the list of 15 most popular programming languages.");
      }

      //Enter the given code here
      location = binarySearch(mostInDemand, name);
      
      System.out.print("\nAccording to Information Week ");

      if(location == -1) {
         System.out.println(name + " is not one of the 10 programming languages " 
         + "that will future-proof your portfolio.");
      } else {
         System.out.println(name + " is one of the 10 programming languages " 
         + "that will future-proof your portfolio.");
      }
   }   

}
