/**
 * ArrayList.java
 * @author Anindita Roy
 *
 * CIS 22C
 */

public class ArrayList<E> {
    private E[] array;
    private int numElements;

    /**
     * Default Constructor
     * Creates an empty Array of length 10
     * Sets numElements to 0
     **/
    @SuppressWarnings("unchecked")
    public ArrayList(){
        final int INITIAL_CAP = 10;
        array = (E[]) new Object[INITIAL_CAP];
        numElements = 0;
    }
    /**
     * Constructor for ArrayList
     *Creates an empty array of length size
     *Sets numElements to 0
     * @param size the initial size of the ArrayList
     */
    @SuppressWarnings("unchecked")
    public ArrayList(int size){
        array = (E[]) new Object[size];
        numElements = 0;

    }
    /**
     * Copy constructor for ArrayList
     * Creates a copy of the parameter list
     * @param original the ArrayList to copy
     */

    @SuppressWarnings("unchecked")
    public ArrayList(ArrayList<E> original) {
        final int INITIAL_CAP = 10;

        if (original == null) {
            array = (E[]) new Object[INITIAL_CAP];
            numElements = 0;
        } else {
            array = (E[]) new Object[original.array.length];
            numElements = original.numElements;

            for (int i = 0; i < numElements; i++) {
                array[i] = original.array[i];
            }
        }
    }
    /**
     * Returns whether the ArrayList is currently empty
     * @return whether the ArrayList is empty
     *
     */
    public boolean isEmpty(){
        return numElements == 0;
    }

    /**
     * Return the current number of elements stored in the ArrayList
     *@return the number of elements
     **/
    public int size(){
        return numElements;
    }
    /**
     * Determines whether th ArrayList is currently full
     * @return whether the ArrayList is at maximum capacity
     * Should be called by the add methods
     **/
    public boolean atCapacity(){
        return numElements == array.length;
    }
    /**
     * Creates a String of all elements, with [] around the elements,
     * each elements separated from the mext with a cpmma
     * @return a String representation of the ArrayList
     *
     */
    public String toString(){
        String result = "[";
        for(int i= 0; i < numElements - 1; i++){
            result += array[i] + ", ";
        }
        if(!isEmpty()){
            result += array[numElements - 1];
        }
        return result + "]";
    }
    /**
     * Returns the element at the specified index.
     * @param index the index of the element to access
     * @return the element at index
     * @throw IndexOutOfBoundsException if provided index is
     * negative or outside the bounds of the array
     **/
    public E get(int index) throws IndexOutOfBoundsException{
        if(index < 0 || index >= numElements){
            throw new IndexOutOfBoundsException("Error: "
                    + "Cannot get element at index " + index + "."
                    + "\nOutside bounds of the ArrayList.\nIndex: "
                    + index + ", Size: " + numElements + "\n");
        }
        return array[index];
    }
    /**
     * Resizes the ArrayList by making a new array
     * that has a lenfth (capacity)
     * 10 Larger than the current array's length (capacity)
     *
     **/
    @SuppressWarnings("unchecked")
    private void reSize(){
        final int RESIZE_BY = 10;
        E[] temp = (E[]) new Object[array.length + RESIZE_BY];

        for(int i = 0; i < numElements; i++){
            temp[i] = array[i];
        }
        array = temp;
    }


    /**
     * Inserts a new element to the end of the list array.
     * Resizes the ArrayList if it is at capacity before inserting
     * @param element the element to insert
     **/
    public void add(E element){
        if(atCapacity()){
            reSize();
        }
        array[numElements] = element;
        numElements++;
    }
    /**
     * Inserts a new element at the specified index in the ArrayList.
     * Resizes the ArrayList if it is at capacity before inserting
     * @param index the index at which to insert
     * @param element the element to insert
     * @throws IndexOutOfBoundsException for invalid indices
     */
    public void add(int index, E element) throws IndexOutOfBoundsException{
        if (index < 0 || index > numElements) {
            throw new IndexOutOfBoundsException("Error:"
                    + " Cannot add at index " + index + "."
                    + "\nIndex is outside the bounds of the ArrayList."
                    + "\nIndex: " + index + ", Size: " + numElements + "\n");
        }

        if (atCapacity()) {
            reSize();
        }

        for (int i = numElements; i > index; i--) {
            array[i] = array[i - 1];
        }

        array[index] = element;
        numElements++;

    }


    /**
     * Replaces the element at the specified index with a new element
     * @param index the index of the element to replace
     * @param element the new element
     * @return the element previously stored at index
     * @throws IndexOutOfBoundsException if index is invalid
     */
    public E set(int index, E element) throws IndexOutOfBoundsException {
        if (index < 0 || index >= numElements) {
            throw new IndexOutOfBoundsException("Error: "
                    + "Cannot set element at index " + index + "."
                    + "\nOutside bounds of the ArrayList.\nIndex: "
                    + index + ", Size: " + numElements + "\n");
        }

        E oldElement = array[index];
        array[index] = element;
        return oldElement;
    }
    /**
     * Searches for the specified element in the ArrayList
     * @param element the value to locate
     * @return true if the value is found, false otherwise
     */
    public boolean contains(E element) {
        if (element == null) {
            return false;
        }

        for (int i = 0; i < numElements; i++) {
            if (array[i].equals(element)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Returns the index of the first matching element
     * @param element the value to locate
     * @return the index of the element, or -1 if not found
     */
    public int indexOf(E element) {
        if (element == null) {
            return -1;
        }

        for (int i = 0; i < numElements; i++) {
            if (array[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }
    /**
     * Removes and returns the element at the specified index
     * @param index the index of the element to remove
     * @return the removed element
     * @throws IndexOutOfBoundsException if the index is invalid
     */
    public E remove(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= numElements) {
            throw new IndexOutOfBoundsException("Error: "
                    + "Cannot remove element at index " + index + "."
                    + "\nOutside bounds of the ArrayList.\nIndex: "
                    + index + ", Size: " + numElements + "\n");
        }

        E removedElement = array[index];

        for (int i = index; i < numElements - 1; i++) {
            array[i] = array[i + 1];
        }

        array[numElements - 1] = null;
        numElements--;

        return removedElement;
    }
    /**
     * Removes the first matching element from the ArrayList
     * @param element the element to remove
     * @return true if the element was removed, false otherwise
     */
    public boolean remove(E element) {
        int index = indexOf(element);

        if (index == -1) {
            return false;
        }

        remove(index);
        return true;
    }
    /**
     * Determines whether two ArrayLists are equal
     * @param obj the object to compare
     * @return whether the lists are equal
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ArrayList)) {
            return false;
        }

        ArrayList<E> other = (ArrayList<E>) obj;

        if (numElements != other.numElements) {
            return false;
        }

        for (int i = 0; i < numElements; i++) {
            if (array[i] == null) {
                if (other.array[i] != null) {
                    return false;
                }
            } else if (!array[i].equals(other.array[i])) {
                return false;
            }
        }

        return true;
    }

}