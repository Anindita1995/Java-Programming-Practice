/**
 * LinkedList.java
 * @author Anindita Roy
 */
import java.util.NoSuchElementException;

public class LinkedList<T> {

    private class Node {
        private T data;
        private Node next;
        private Node prev;

        /**
         * Creates a new Node with given data.
         *
         * @param data the data stored in the node
         */
        public Node(T data) {
            this.data = data;
            this.next = null;
            this.prev = null;
        }
    }

    private Node first;
    private Node last;
    private int length;
    private Node iterator;

    /**
     * Instantiates a new LinkedList with default values.
     *
     * @postcondition first and last are null, and length is 0
     */
    public LinkedList() {
        first = null;
        last = null;
        length = 0;
    }
    /**
     * Instantiates a new LinkedList by copying another LinkedList
     * @param original, the LinkedList to copy
     * @postcondition a new List object, which is an identical but separate
     * copy if the LinkedList original
     */
    public LinkedList(LinkedList<T> original){
        if(original == null){
            return;
        }
        if(original.length == 0){
            length = 0;
            first = null;
            last = null;
            iterator = null;
        } else{
            Node temp = original.first;
            while(temp != null){
                addLast(temp.data);
                temp = temp.next;
            }
            iterator = null;
        }


    }

    /**
     * Instantiates a new LinkedList from an array.
     *
     * @param array the array of values to add to this LinkedList
     * @postcondition if array is not null, each array element is added to this LinkedList
     * in the same order
     */
    public LinkedList(T[] array) {
        first = null;
        last = null;
        length = 0;
        iterator = null;

        if (array == null) {
            return;
        }

        for (int i = 0; i < array.length; i++) {
            addLast(array[i]);
        }
    }

    /**
     * Creates a new first element.
     *
     * @param data the data to insert at the front of the LinkedList
     * @postcondition a new node is added at the front of the list
     */
    public void addFirst(T data) {
        Node dataNode = new Node(data);

        if (length == 0) {
            first = last = dataNode;
        } else {
            first.prev = dataNode;
            dataNode.next = first;
            first = dataNode;
        }

        length++;
    }

    /**
     * Creates a new last element.
     *
     * @param data the data to insert at the end of the LinkedList
     * @postcondition a new node is added at the end of the list
     */
    public void addLast(T data) {
        Node dataNode = new Node(data);

        if (length == 0) {
            first = last = dataNode;
        } else {
            last.next = dataNode;
            dataNode.prev = last;
            last = dataNode;
        }

        length++;
    }

    /**
     * Returns the value stored in the first node.
     *
     * @precondition LinkedList must not be empty
     * @return the value stored in the first node
     * @throws NoSuchElementException when LinkedList is empty
     */
    public T getFirst() throws NoSuchElementException {
        if (length == 0) {
            throw new NoSuchElementException("getFirst(): LinkedList cannot be empty.");
        }

        return first.data;
    }

    /**
     * Returns the value stored in the last node.
     *
     * @precondition LinkedList must not be empty
     * @return the value stored in the last node
     * @throws NoSuchElementException when LinkedList is empty
     */
    public T getLast() throws NoSuchElementException {
        if (length == 0) {
            throw new NoSuchElementException("getLast(): LinkedList cannot be empty.");
        }

        return last.data;
    }

    /**
     * Returns the current length of the LinkedList.
     *
     * @return the length of the LinkedList
     */
    public int getLength() {
        return length;
    }

    /**
     * Returns whether the LinkedList is currently empty.
     *
     * @return true if the LinkedList is empty, false otherwise
     */
    public boolean isEmpty() {
        return length == 0;
    }

    /**
     * Removes the element at the front of the LinkedList.
     *
     * @precondition LinkedList must not be empty
     * @postcondition the first element of the list is removed
     * @throws NoSuchElementException when LinkedList is empty
     */
    public void removeFirst() throws NoSuchElementException {
        if (length == 0) {
            throw new NoSuchElementException("removeFirst(): LinkedList cannot be empty.");
        }
        if (iterator == first) {
            iterator = null;
        }
        if (length == 1) {
            first = null;
            last = null;
        } else {
            first = first.next;
            first.prev = null;
        }

        length--;
    }

    /**
     * Removes the element at the end of the LinkedList.
     *
     * @precondition LinkedList must not be empty
     * @postcondition the last element of the list is removed
     * @throws NoSuchElementException when LinkedList is empty
     */
    public void removeLast() throws NoSuchElementException {
        if (length == 0) {
            throw new NoSuchElementException("removeLast(): LinkedList cannot be empty.");
        }
        if (iterator == last) {
            iterator = null;
        }
        if (length == 1) {
            first = null;
            last = null;
        } else {
            last = last.prev;
            last.next = null;
        }

        length--;
    }

    /**
     * Converts the LinkedList to a String, with each value separated by a blank space.
     * At the end of the String, places a new line character.
     *
     * @return the LinkedList as a String
     */
    @Override
    public String toString() {
        String result = "";
        Node temp = first;

        while (temp != null) {
            result += temp.data + " ";
            temp = temp.next;
        }

        return result + "\n";
    }

    /**** ADDITIONAL OPERATIONS ****/

    /**
     * Returns each element in the LinkedList with its numerical position.
     *
     * @return a numbered String of LinkedList elements
     */
    public String numberedListString() {
        StringBuilder result = new StringBuilder();
        Node temp = first;

        for (int i = 1; i <= length; i++) {
            result.append(i).append(". ").append(temp.data).append("\n");
            temp = temp.next;
        }

        result.append("\n");

        return result.toString();
    }

    /**
     * Return the data at the iterator position
     * @return the data stored at iterator position
     * @throws NullPointerException if the interator is off end
     **/

    public T getIterator(){
        if(iterator == null){
            throw new NullPointerException("getIterator(): cannot get a null iterator.");
        }else{
            return iterator.data;
        }
    }
    /**
     * Places the iterator at the first node in the list.
     *
     * @postcondition the iterator points to the first node
     */
    public void positionIterator() {
        iterator = first;
    }
    /**
     * Returns whether the iterator is currently off end.
     *
     * @return true if the iterator is null, false otherwise
     */
    public boolean offEnd(){

        return iterator == null;
    }

    /**
     * Moves the iterator one node toward the front of the list.
     *
     * @throws NullPointerException if the iterator is null
     */
    public void reverseIterator() {
        if (iterator == null) {
            throw new NullPointerException("reverseIterator(): cannot reverse a null iterator.");
        }
        iterator = iterator.prev;
    }
    /**
     * Moves the iterator one position toward the end of the list.
     *
     * @throws NullPointerException if the iterator is null
     */
    public void advanceIterator() {
        if (iterator == null) {
            throw new NullPointerException("advanceIterator(): cannot advance a null iterator.");
        }
        iterator = iterator.next;
    }
    /**
     * Inserts a new node after the iterator.
     *
     * @param data the data to insert
     * @throws NullPointerException if the iterator is null
     */
    public void addIterator(T data) {
        if (iterator == null) {
            throw new NullPointerException("addIterator(): cannot insert after a null iterator.");
        }

        Node newNode = new Node(data);

        if (iterator == last) {
            newNode.prev = last;
            last.next = newNode;
            last = newNode;
        } else {
            newNode.next = iterator.next;
            newNode.prev = iterator;
            iterator.next.prev = newNode;
            iterator.next = newNode;
        }

        length++;
    }
    /**
     * Removes the node at the iterator position.
     *
     * @throws NullPointerException if the iterator is null
     */
    public void removeIterator() {
        if (iterator == null) {
            throw new NullPointerException("removeIterator(): cannot remove a null iterator.");
        }

        if (length == 1) {
            first = null;
            last = null;
        } else if (iterator == first) {
            first = first.next;
            first.prev = null;
        } else if (iterator == last) {
            last = last.prev;
            last.next = null;
        } else {
            iterator.prev.next = iterator.next;
            iterator.next.prev = iterator.prev;
        }

        iterator = null;
        length--;
    }
    /**
     * Compares this LinkedList with the specified Object for equality.
     * Returns true when the specified Object is also a LinkedList
     * with the same length and the same elements in the same order.
     *
     * @param obj the Object to compare with this LinkedList
     * @return true if this LinkedList and obj are equal, false otherwise
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object obj){
        if(obj == this){
            return true;
        }else if(!(obj instanceof LinkedList)){
            return false;
        } else{
            LinkedList<T> list = (LinkedList<T>) obj;
            if(this.length != list.length){
                return false;
            }else{
                Node temp1 = this.first;
                LinkedList<T>.Node temp2 = list.first;
                while (temp1 != null) {
                    if (temp1.data == null) {
                        if (temp2.data != null) {
                            return false;
                        }
                    } else if (!temp1.data.equals(temp2.data)) {
                        return false;
                    }

                    temp1 = temp1.next;
                    temp2 = temp2.next;
                }

            }
        }
        return true;
    }
    /**
     * Removes all elements from this LinkedList.
     *
     * @postcondition first, last, and iterator are null, and length is 0
     */
    public void clear() {
        first = null;
        last = null;
        iterator = null;
        length = 0;
    }



/**** MORE METHODS ****/
    /**
     * Searches the LinkedList for the index of the given data.
     *
     * @param data the data whose index to locate
     * @return the index of the data, or -1 if the data is not in the LinkedList
     */
    public int findIndex(T data) {
        Node temp = first;
        int index = 0;

        while (temp != null) {
            if (temp.data == null) {
                if (data == null) {
                    return index;
                }
            } else if (temp.data.equals(data)) {
                return index;
            }

            temp = temp.next;
            index++;
        }

        return -1;
    }

    /**
     * Advances the iterator to the node at the given index.
     *
     * @param index the index at which to place the iterator
     * @throws IndexOutOfBoundsException when index is out of bounds
     */
    public void advanceIteratorToIndex(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= length) {
            throw new IndexOutOfBoundsException("advanceIteratorToIndex(): index out of bounds.");
        }

        iterator = first;

        for (int i = 0; i < index; i++) {
            iterator = iterator.next;
        }
    }

}