/**
 * HashTable.java
 * @author Anindita Roy
 * CIS 22C
 */

public class HashTable<T> {
    private int numElements;
    private ArrayList<LinkedList<T> > table;

    /** Constructors */
    /**
     * Constructs a new HashTable with the given size.
     *
     * @param size the number of buckets in the HashTable
     * @throws IllegalArgumentException if size is less than or equal to 0
     */
    public HashTable(int size) throws IllegalArgumentException {
        if (size <= 0) {
            throw new IllegalArgumentException("HashTable size must be greater than 0.");
        }

        table = new ArrayList<LinkedList<T>>(size);

        for (int i = 0; i < size; i++) {
            table.add(new LinkedList<T>());
        }

        numElements = 0;
    }
    /**
     * Constructs a new HashTable with the given array elements and table size.
     * Inserts each element from the array into the appropriate bucket.
     *
     * @param array the array of elements to insert into the HashTable
     * @param size the number of buckets in the HashTable
     * @throws IllegalArgumentException if size is less than or equal to 0
     */

    public HashTable(T[] array, int size)throws IllegalArgumentException{
        if(size <= 0){
            throw new IllegalArgumentException("HashTable size must be greater than 0.");
        }
        table = new ArrayList<LinkedList<T>>(size);

        for(int i = 0; i < size; i++){
            table.add(new LinkedList<T>());
        }
        numElements = 0;
        if(array != null){
            for(int i = 0; i < array.length; i++){
                if(array[i] != null){
                    add(array[i]);
                }
            }
        }
    }
    /** Accessors */
    /**
     * Returns the bucket index for the given object.
     *
     * @param obj the object to hash
     * @return the index in the table
     */
    private int hash(T obj) {
        int code = obj.hashCode();
        int index = code % table.size();
        if (index < 0) {
            index += table.size();
        }
        return index;
    }
    /**
     * Returns the number of elements stored in the specified bucket.
     *
     * @param index the bucket index to count
     * @return the number of elements in the bucket
     * @throws IndexOutOfBoundsException if index is out of bounds
     */
    public int countBucket(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= table.size()) {
            throw new IndexOutOfBoundsException("countBucket(): index is out of bounds.");
        }

        return table.get(index).getLength();
    }
    /**
     * Determines whether the HashTable contains the specified element.
     *
     * @param elmt the element to search for
     * @return true if the element is found, otherwise false
     * @throws NullPointerException if elmt is null
     */
    public boolean contains(T elmt) throws NullPointerException {
        if (elmt == null) {
            throw new NullPointerException("contains(): cannot search for a null element.");
        }

        return get(elmt) != null;
    }
    /**
     * Deletes the specified element from the HashTable.
     *
     * @param elmt the element to delete
     * @return true if the element was deleted, otherwise false
     * @throws NullPointerException if elmt is null
     */
    public boolean delete(T elmt) throws NullPointerException {
        if (elmt == null) {
            throw new NullPointerException("delete(): cannot delete a null element.");
        }

        int bucket = hash(elmt);
        int index = table.get(bucket).findIndex(elmt);

        if (index == -1) {
            return false;
        }

        table.get(bucket).advanceIteratorToIndex(index);
        table.get(bucket).removeIterator();
        numElements--;

        return true;
    }
    /**
     * Removes all elements from the HashTable.
     */
    public void clear() {
        for (int i = 0; i < table.size(); i++) {
            table.set(i, new LinkedList<T>());
        }

        numElements = 0;
    }
    /**
     * Creates a String representation of the first element in each bucket.
     *
     * @return a String containing each bucket number and its first element, or empty if the bucket has no elements
     */
    public String rowToString() {
        String result = "";

        for (int i = 0; i < table.size(); i++) {
            result += "Bucket " + i + ": ";

            if (table.get(i).isEmpty()) {
                result += "empty";
            } else {
                table.get(i).positionIterator();
                result += table.get(i).getIterator();
            }

            result += "\n";
        }

        return result;
    }

    /**
     * Returns the number of elements in the HashTable.
     *
     * @return the number of elements
     */
    public int getNumElements() {
        return numElements;
    }

    /**
     * Accesses a specified key in the HashTable.
     *
     * @param elmt the key to search for
     * @return the value to which the specified key is mapped, or null if this table
     * contains no mapping for the key
     * @precondition elmt must not be null
     * @throws NullPointerException when elmt is null
     */
    public T get(T elmt) throws NullPointerException {
        if (elmt == null) {
            throw new NullPointerException("get(): cannot get a null element.");
        }

        int bucket = hash(elmt);
        int index = table.get(bucket).findIndex(elmt);

        if (index == -1) {
            return null;
        }

        table.get(bucket).advanceIteratorToIndex(index);
        return table.get(bucket).getIterator();
    }
    /**
     * Searches for an element in the HashTable.
     *
     * @param elmt the element to locate
     * @return the bucket number where the element is located, or -1 if it is not found
     * @precondition elmt must not be null
     * @throws NullPointerException when elmt is null
     */
    public int find(T elmt) throws NullPointerException {
        if (elmt == null) {
            throw new NullPointerException("find(): cannot search null element.");
        }

        int bucket = hash(elmt);

        if (get(elmt) == null) {
            return -1;
        }

        return bucket;
    }


    /** Mutators */
    /**
     * Inserts a new element into the HashTable.
     *
     * @param elmt the element to insert
     * @precondition elmt must not be null
     * @throws NullPointerException when elmt is null
     */
    public void add(T elmt) throws NullPointerException {
        if (elmt == null) {
            throw new NullPointerException("add(): cannot add a null element.");
        }

        int index = hash(elmt);
        table.get(index).addLast(elmt);
        numElements++;
    }
    /** Additional Methods */
    /**
     * Creates a String representation of the HashTable.
     *
     * @return a String containing all elements in the HashTable by bucket
     */
    @Override
    public String toString() {
        String result = "";

        for (int i = 0; i < table.size(); i++) {
            if (!table.get(i).isEmpty()) {
                result += table.get(i).toString();
            }
        }

        return result + "\n";
    }


    /**
     * Computes the load factor of the HashTable.
     *
     * @return the load factor
     */
    public double getLoadFactor() {
        return (double) numElements / table.size();
    }
    /**
     * Creates a String of all elements at a given bucket.
     *
     * @param bucket the index in the table
     * @return a String of elements, separated by spaces with a new line character at the end
     * @precondition bucket must be within the bounds of the table
     * @throws IndexOutOfBoundsException when bucket is out of bounds
     */
    public String bucketToString(int bucket) throws IndexOutOfBoundsException {
        if (bucket < 0 || bucket >= table.size()) {
            throw new IndexOutOfBoundsException("bucketToString(): bucket is out of bounds.");
        }

        return table.get(bucket).toString();
    }




}
